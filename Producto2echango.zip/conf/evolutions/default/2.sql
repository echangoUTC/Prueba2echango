# --- Sample dataset

# --- !Ups

insert into producto (id,name,precio,fecha) values (  1,'Sopa','2,50','2016-12-12');
insert into producto (id,name,precio,fecha) values (  2,'Arroz con camaron','5,00','2016-12-12');
insert into producto (id,name,precio,fecha) values (  3,'Postre de sandia','1,50','2016-12-12');
insert into producto (id,name,precio,fecha) values (  4,'Sopa de verduras','3,50','2016-12-12');
insert into producto (id,name,precio,fecha) values (  5,'Jugo de limon','1,50','2016-12-12');
insert into producto (id,name,precio,fecha) values (  6,'Arroz de pollo','2,50','2016-12-12');
insert into producto (id,name,precio,fecha) values (  7,'Parrillada','3,50','2016-12-12');
insert into producto (id,name,precio,fecha) values (  8,'Papi pollo','2,50','2016-12-12');
insert into producto (id,name,precio,fecha) values (  9,'Tortas','2,50','2016-12-12');
insert into producto (id,name,precio,fecha) values (  10,'Aguas Aromaticas','0,50','2016-12-12');
insert into producto (id,name,precio,fecha) values (  11,'Pollo al Horno','1,50','2016-12-12');
insert into producto (id,name,precio,fecha) values (  12,'Ensaladas','1,50','2016-12-12');
insert into producto (id,name,precio,fecha) values (  13,'Postres','3,50','2016-12-12');
insert into producto (id,name,precio,fecha) values (  14,'Arroz Verde ','2,50','2016-12-12');
insert into producto (id,name,precio,fecha) values (  15,'Tallarin Especial','3,50','2016-12-12');
insert into producto (id,name,precio,fecha) values (  16,'Colas','1,50','2016-12-12');
insert into producto (id,name,precio,fecha) values (  17,'Golosinas','1,00','2016-12-12');
insert into producto (id,name,precio,fecha) values (  18,'Chocolates','2,50','2016-12-12');
insert into producto (id,name,precio,fecha) values (  19,'Ceviche','2,50','2016-12-12');
insert into producto (id,name,precio,fecha) values (  20,'Cencebollado','2,50','2016-12-12');

# --- !Downs

delete from producto;

